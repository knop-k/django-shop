from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password, check_password
from .models.product import Product
from .models.category import Category
from .models.customer import Customer
from django.views import View

# Create your views here.
# def index(request):
#     categories = Category.get_all_categories()
#     categoryID = request.GET.get('category')
#     if categoryID:
#         products = Product.get_all_product_by_category_id(categoryID)
#     else:
#         products = Product.get_all_products()
#
#     data = {}
#     data['products'] = products
#     data['categories'] = categories
#     # return render(request, 'orders/order.html')
#     return render(request, 'index.html', data)





# def register_user(request):
#     post_data = request.POST
#     first_name = post_data.get('first_name')
#     last_name = post_data.get('last_name')
#     phone = post_data.get('phone')
#     email = post_data.get('email')
#     password = post_data.get('password')
#     # validation
#     value = {
#         'first_name': first_name,
#         'last_name': last_name,
#         'phone': phone,
#         'email': email,
#     }
#     error_message = ''
#
#     customer = Customer(first_name=first_name,
#                         last_name=last_name,
#                         phone=phone,
#                         email=email,
#                         password=password)
#
#     error_message = validate_customer(customer)
#
#     # saving
#     if not error_message:
#         customer.password = make_password(customer.password)
#         customer.register()
#         return redirect('homepage')
#     else:
#         data = {
#             'error': error_message,
#             'values': value
#         }
#         return render(request, 'signup.html', data)


# def signup(request):
#     if request.method == 'GET':
#         return render(request, 'signup.html')
#     else:
#         return register_user(request)





# def login(request):
#     if request.method == 'GET':
#         return render(request, 'login.html')
#     else:
#         email = request.POST.get('email')
#         password = request.POST.get('password')
#         customer = Customer.get_customer_by_email(email)
#         error_message = None
#         if customer:
#             flag = check_password(password, customer.password)
#             if flag:
#                 return redirect('homepage')
#
#             else:
#                 error_message = 'Email or password invalid'
#         else:
#             error_message = 'Email or password invalid'
#         return render(request, 'login.html', {'error': error_message})
