from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from store.models.customer import Customer
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        post_data = request.POST
        first_name = post_data.get('first_name')
        last_name = post_data.get('last_name')
        phone = post_data.get('phone')
        email = post_data.get('email')
        password = post_data.get('password')
        # validation
        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email,
        }
        error_message = ''

        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            phone=phone,
                            email=email,
                            password=password)

        error_message = self.validate_customer(customer)

        # saving
        if not error_message:
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('homepage')
        else:
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)

    def validate_customer(self, customer):
        error_message = None
        if (not customer.first_name):
            error_message = 'First name required!'
        elif len(customer.first_name) < 4:
            error_message = 'First name must be 4 char or more'

        elif not customer.last_name:
            error_message = 'Last name required!'
        elif len(customer.last_name) < 4:
            error_message = 'Last name must be 4 char or more'

        elif not customer.phone:
            error_message = 'Phone number required!'
        elif len(customer.phone) < 10:
            error_message = 'Phone number must be 10 char long'

        elif len(customer.password) < 6:
            error_message = 'Password must be 6 char long'
        elif len(customer.password) < 5:
            error_message = 'Password must be 5 char long'

        elif customer.isExist():
            error_message = 'Email Addrress already registered ..'

        return error_message
